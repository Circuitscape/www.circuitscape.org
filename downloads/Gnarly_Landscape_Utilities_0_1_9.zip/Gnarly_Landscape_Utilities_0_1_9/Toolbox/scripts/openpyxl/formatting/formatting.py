

class ConditionalFormatting(object):

    def __init__(self):
        self.ranges = {}
        self.priority = 0

    def add(self, range_string, rule):
        pass

